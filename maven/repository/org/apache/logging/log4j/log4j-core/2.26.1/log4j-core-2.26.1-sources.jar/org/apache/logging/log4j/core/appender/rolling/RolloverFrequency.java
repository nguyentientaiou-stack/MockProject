/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to you under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.logging.log4j.core.appender.rolling;

/**
 * Enumeration of rollover frequency values.
 */
public enum RolloverFrequency {
    /** Rollover annually. */
    ANNUALLY,
    /** Rollover monthly. */
    MONTHLY,
    /** Rollover weekly. */
    WEEKLY,
    /** Rollover daily. */
    DAILY,
    /** Rollover every hour. */
    HOURLY,
    /** Rollover every minute. */
    EVERY_MINUTE,
    /** Rollover every second. */
    EVERY_SECOND,
    /** Rollover every millisecond. */
    EVERY_MILLISECOND
}
