/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to you under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.logging.log4j.core.appender.rolling;

/**
 * Implementations of this interface that are registered with the RollingFileManager will be notified before and
 * after a rollover occurs. This is a synchronous call so Listeners should exit the methods as fast as possible.
 * It is recommended that they simply notify some other already active thread.
 */
public interface RolloverListener {

    /**
     * Called before rollover.
     * @param fileName The name of the file rolling over.
     */
    void rolloverTriggered(String fileName);

    /**
     * Called after rollover.
     * @param fileName The name of the file rolling over.
     */
    void rolloverComplete(String fileName);
}
