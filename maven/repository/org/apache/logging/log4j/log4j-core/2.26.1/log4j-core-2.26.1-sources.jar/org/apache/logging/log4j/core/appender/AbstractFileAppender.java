/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to you under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.logging.log4j.core.appender;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.Layout;
import org.apache.logging.log4j.core.config.Property;
import org.apache.logging.log4j.core.config.plugins.PluginBuilderAttribute;
import org.apache.logging.log4j.core.config.plugins.validation.constraints.Required;
import org.apache.logging.log4j.core.net.Advertiser;

/**
 * Abstract File Appender.
 */
public abstract class AbstractFileAppender<M extends OutputStreamManager> extends AbstractOutputStreamAppender<M> {

    /**
     * Builds FileAppender instances.
     *
     * @param <B>
     *            The type to build
     */
    public abstract static class Builder<B extends Builder<B>> extends AbstractOutputStreamAppender.Builder<B> {

        @PluginBuilderAttribute
        @Required
        private String fileName;

        @PluginBuilderAttribute
        private boolean append = true;

        @PluginBuilderAttribute
        private boolean locking;

        @PluginBuilderAttribute
        private boolean advertise;

        @PluginBuilderAttribute
        private String advertiseUri;

        @PluginBuilderAttribute
        private boolean createOnDemand;

        @PluginBuilderAttribute
        private String filePermissions;

        @PluginBuilderAttribute
        private String fileOwner;

        @PluginBuilderAttribute
        private String fileGroup;

        public String getAdvertiseUri() {
            return advertiseUri;
        }

        public String getFileName() {
            return fileName;
        }

        public boolean isAdvertise() {
            return advertise;
        }

        public boolean isAppend() {
            return append;
        }

        public boolean isCreateOnDemand() {
            return createOnDemand;
        }

        public boolean isLocking() {
            return locking;
        }

        public String getFilePermissions() {
            return filePermissions;
        }

        public String getFileOwner() {
            return fileOwner;
        }

        public String getFileGroup() {
            return fileGroup;
        }

        /**
         * @since 2.26.0
         */
        public B setAdvertise(final boolean advertise) {
            this.advertise = advertise;
            return asBuilder();
        }

        /**
         * @since 2.26.0
         */
        public B setAdvertiseUri(final String advertiseUri) {
            this.advertiseUri = advertiseUri;
            return asBuilder();
        }

        /**
         * @since 2.26.0
         */
        public B setAppend(final boolean append) {
            this.append = append;
            return asBuilder();
        }

        /**
         * @since 2.26.0
         */
        public B setFileName(final String fileName) {
            this.fileName = fileName;
            return asBuilder();
        }

        /**
         * @since 2.26.0
         */
        public B setCreateOnDemand(final boolean createOnDemand) {
            this.createOnDemand = createOnDemand;
            return asBuilder();
        }

        /**
         * @since 2.26.0
         */
        public B setLocking(final boolean locking) {
            this.locking = locking;
            return asBuilder();
        }

        /**
         * @since 2.26.0
         */
        public B setFilePermissions(final String filePermissions) {
            this.filePermissions = filePermissions;
            return asBuilder();
        }

        /**
         * @since 2.26.0
         */
        public B setFileOwner(final String fileOwner) {
            this.fileOwner = fileOwner;
            return asBuilder();
        }

        /**
         * @since 2.26.0
         */
        public B setFileGroup(final String fileGroup) {
            this.fileGroup = fileGroup;
            return asBuilder();
        }

        /**
         * @deprecated since 2.26.0 use {@link #setAdvertise(boolean)}.
         */
        @Deprecated
        public B withAdvertise(final boolean advertise) {
            this.advertise = advertise;
            return asBuilder();
        }

        /**
         * @deprecated since 2.26.0 use {@link #setAdvertiseUri(String)}.
         */
        @Deprecated
        public B withAdvertiseUri(final String advertiseUri) {
            this.advertiseUri = advertiseUri;
            return asBuilder();
        }

        /**
         * @deprecated since 2.26.0 use {@link #setAppend(boolean)}.
         */
        @Deprecated
        public B withAppend(final boolean append) {
            this.append = append;
            return asBuilder();
        }

        /**
         * @deprecated since 2.26.0 use {@link #setFileName(String)}.
         */
        @Deprecated
        public B withFileName(final String fileName) {
            this.fileName = fileName;
            return asBuilder();
        }

        /**
         * @deprecated since 2.26.0 use {@link #setCreateOnDemand(boolean)}.
         */
        @Deprecated
        public B withCreateOnDemand(final boolean createOnDemand) {
            this.createOnDemand = createOnDemand;
            return asBuilder();
        }

        /**
         * @deprecated since 2.26.0 use {@link #setLocking(boolean)}.
         */
        @Deprecated
        public B withLocking(final boolean locking) {
            this.locking = locking;
            return asBuilder();
        }

        /**
         * @deprecated since 2.26.0 use {@link #setFilePermissions(String)}.
         */
        @Deprecated
        public B withFilePermissions(final String filePermissions) {
            this.filePermissions = filePermissions;
            return asBuilder();
        }

        /**
         * @deprecated since 2.26.0 use {@link #setFileOwner(String)}.
         */
        @Deprecated
        public B withFileOwner(final String fileOwner) {
            this.fileOwner = fileOwner;
            return asBuilder();
        }

        /**
         * @deprecated since 2.26.0 use {@link #setFileGroup(String)}.
         */
        @Deprecated
        public B withFileGroup(final String fileGroup) {
            this.fileGroup = fileGroup;
            return asBuilder();
        }
    }

    private final String fileName;

    private final Advertiser advertiser;

    private final Object advertisement;

    private AbstractFileAppender(
            final String name,
            final Layout<? extends Serializable> layout,
            final Filter filter,
            final M manager,
            final String filename,
            final boolean ignoreExceptions,
            final boolean immediateFlush,
            final Advertiser advertiser,
            final Property[] properties) {

        super(name, layout, filter, ignoreExceptions, immediateFlush, properties, manager);
        if (advertiser != null) {
            final Map<String, String> configuration = new HashMap<>(layout.getContentFormat());
            configuration.putAll(manager.getContentFormat());
            configuration.put("contentType", layout.getContentType());
            configuration.put("name", name);
            advertisement = advertiser.advertise(configuration);
        } else {
            advertisement = null;
        }
        this.fileName = filename;
        this.advertiser = advertiser;
    }

    /**
     * Returns the file name this appender is associated with.
     * @return The File name.
     */
    public String getFileName() {
        return this.fileName;
    }

    @Override
    public boolean stop(final long timeout, final TimeUnit timeUnit) {
        setStopping();
        super.stop(timeout, timeUnit, false);
        if (advertiser != null) {
            advertiser.unadvertise(advertisement);
        }
        setStopped();
        return true;
    }
}
