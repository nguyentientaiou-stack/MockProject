package org.openqa.selenium.devtools.v150.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public enum LocalNetworkAccessRequestPolicy {

    ALLOW("Allow"), BLOCKFROMINSECURETOMOREPRIVATE("BlockFromInsecureToMorePrivate"), WARNFROMINSECURETOMOREPRIVATE("WarnFromInsecureToMorePrivate"), PERMISSIONBLOCK("PermissionBlock"), PERMISSIONWARN("PermissionWarn");

    private String value;

    LocalNetworkAccessRequestPolicy(String value) {
        this.value = value;
    }

    public static LocalNetworkAccessRequestPolicy fromString(String s) {
        return java.util.Arrays.stream(LocalNetworkAccessRequestPolicy.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within LocalNetworkAccessRequestPolicy "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static LocalNetworkAccessRequestPolicy fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}
