package org.openqa.selenium.devtools.v150.audits.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public enum PerformanceIssueType {

    DOCUMENTCOOKIE("DocumentCookie");

    private String value;

    PerformanceIssueType(String value) {
        this.value = value;
    }

    public static PerformanceIssueType fromString(String s) {
        return java.util.Arrays.stream(PerformanceIssueType.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within PerformanceIssueType "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static PerformanceIssueType fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}
