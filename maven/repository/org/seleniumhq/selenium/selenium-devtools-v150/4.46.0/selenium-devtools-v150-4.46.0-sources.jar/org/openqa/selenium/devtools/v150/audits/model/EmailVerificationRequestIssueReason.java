package org.openqa.selenium.devtools.v150.audits.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Represents the failure reason when an email verification request fails.
 * Should be updated alongside EmailVerificationRequestResult in
 * third_party/blink/public/mojom/devtools/inspector_issue.mojom.
 */
public enum EmailVerificationRequestIssueReason {

    INVALIDEMAIL("InvalidEmail"),
    DNSFETCHFAILED("DnsFetchFailed"),
    DNSINVALIDRECORD("DnsInvalidRecord"),
    WELLKNOWNHTTPNOTFOUND("WellKnownHttpNotFound"),
    WELLKNOWNNORESPONSE("WellKnownNoResponse"),
    WELLKNOWNINVALIDRESPONSE("WellKnownInvalidResponse"),
    WELLKNOWNLISTEMPTY("WellKnownListEmpty"),
    WELLKNOWNINVALIDCONTENTTYPE("WellKnownInvalidContentType"),
    WELLKNOWNMISSINGISSUANCEENDPOINT("WellKnownMissingIssuanceEndpoint"),
    WELLKNOWNISSUANCEENDPOINTCROSSORIGIN("WellKnownIssuanceEndpointCrossOrigin"),
    WELLKNOWNUNSUPPORTEDSIGNINGALGORITHM("WellKnownUnsupportedSigningAlgorithm"),
    TOKENHTTPNOTFOUND("TokenHttpNotFound"),
    TOKENNORESPONSE("TokenNoResponse"),
    TOKENINVALIDRESPONSE("TokenInvalidResponse"),
    TOKENINVALIDCONTENTTYPE("TokenInvalidContentType"),
    TOKENMALFORMEDSDJWT("TokenMalformedSdJwt"),
    TOKENINVALIDSDJWT("TokenInvalidSdJwt"),
    KEYBINDINGSIGNINGFAILED("KeyBindingSigningFailed"),
    RPORIGINISOPAQUE("RpOriginIsOpaque"),
    WELLKNOWNMISSINGACCOUNTSENDPOINT("WellKnownMissingAccountsEndpoint"),
    USERLOGGEDOUT("UserLoggedOut"),
    WELLKNOWNACCOUNTSENDPOINTCROSSORIGIN("WellKnownAccountsEndpointCrossOrigin"),
    ACCOUNTSHTTPNOTFOUND("AccountsHttpNotFound"),
    ACCOUNTSNORESPONSE("AccountsNoResponse"),
    ACCOUNTSINVALIDRESPONSE("AccountsInvalidResponse"),
    ACCOUNTSINVALIDCONTENTTYPE("AccountsInvalidContentType"),
    ACCOUNTSEMPTYLIST("AccountsEmptyList"),
    EMAILVERIFICATIONWELLKNOWNHTTPNOTFOUND("EmailVerificationWellKnownHttpNotFound"),
    EMAILVERIFICATIONWELLKNOWNNORESPONSE("EmailVerificationWellKnownNoResponse"),
    EMAILVERIFICATIONWELLKNOWNINVALIDRESPONSE("EmailVerificationWellKnownInvalidResponse"),
    EMAILVERIFICATIONWELLKNOWNINVALIDCONTENTTYPE("EmailVerificationWellKnownInvalidContentType"),
    JWKSHTTPNOTFOUND("JwksHttpNotFound"),
    JWKSINVALIDRESPONSE("JwksInvalidResponse"),
    TOKENVERIFICATIONSDJWTUNSUPPORTEDHEADERALG("TokenVerificationSdJwtUnsupportedHeaderAlg"),
    TOKENVERIFICATIONSDJWTMISSINGISS("TokenVerificationSdJwtMissingIss"),
    TOKENVERIFICATIONSDJWTMISSINGIAT("TokenVerificationSdJwtMissingIat"),
    TOKENVERIFICATIONSDJWTMISSINGCNF("TokenVerificationSdJwtMissingCnf"),
    TOKENVERIFICATIONSDJWTMISSINGEMAIL("TokenVerificationSdJwtMissingEmail"),
    TOKENVERIFICATIONSDJWTINVALIDISSUEDAT("TokenVerificationSdJwtInvalidIssuedAt"),
    TOKENVERIFICATIONSDJWTINVALIDISSUER("TokenVerificationSdJwtInvalidIssuer"),
    TOKENVERIFICATIONSDJWTJWKSMISSINGKEYS("TokenVerificationSdJwtJwksMissingKeys"),
    TOKENVERIFICATIONSDJWTSIGNATUREFAILED("TokenVerificationSdJwtSignatureFailed"),
    TOKENVERIFICATIONSDJWTINVALIDEMAILVERIFIED("TokenVerificationSdJwtInvalidEmailVerified"),
    TOKENVERIFICATIONSDJWTINVALIDEMAIL("TokenVerificationSdJwtInvalidEmail"),
    TOKENVERIFICATIONSDJWTINVALIDHOLDERKEY("TokenVerificationSdJwtInvalidHolderKey"),
    TOKENVERIFICATIONKBINVALIDTYP("TokenVerificationKbInvalidTyp"),
    TOKENVERIFICATIONKBMISSINGAUD("TokenVerificationKbMissingAud"),
    TOKENVERIFICATIONKBMISSINGNONCE("TokenVerificationKbMissingNonce"),
    TOKENVERIFICATIONKBMISSINGIAT("TokenVerificationKbMissingIat"),
    TOKENVERIFICATIONKBMISSINGSDHASH("TokenVerificationKbMissingSdHash"),
    TOKENVERIFICATIONKBINVALIDISSUEDAT("TokenVerificationKbInvalidIssuedAt"),
    TOKENVERIFICATIONKBINVALIDAUDIENCE("TokenVerificationKbInvalidAudience"),
    TOKENVERIFICATIONKBINVALIDNONCE("TokenVerificationKbInvalidNonce"),
    TOKENVERIFICATIONKBINVALIDSDHASH("TokenVerificationKbInvalidSdHash"),
    TOKENVERIFICATIONKBMISSINGCNF("TokenVerificationKbMissingCnf"),
    TOKENVERIFICATIONKBSIGNATUREFAILED("TokenVerificationKbSignatureFailed");

    private String value;

    EmailVerificationRequestIssueReason(String value) {
        this.value = value;
    }

    public static EmailVerificationRequestIssueReason fromString(String s) {
        return java.util.Arrays.stream(EmailVerificationRequestIssueReason.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within EmailVerificationRequestIssueReason "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static EmailVerificationRequestIssueReason fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}
