package org.openqa.selenium.devtools.v150.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Represents the provenance of an ad resource or element. Only one of
 * `filterlistRule` or `adScriptAncestry` can be set. If `filterlistRule`
 * is provided, the resource URL directly matches a filter list rule. If
 * `adScriptAncestry` is provided, an ad script initiated the resource fetch or
 * appended the element to the DOM. If neither is provided, the entity is
 * known to be an ad, but provenance tracking information is unavailable.
 */
@org.openqa.selenium.Beta()
public class AdProvenance {

    private final java.util.Optional<java.lang.String> filterlistRule;

    private final java.util.Optional<org.openqa.selenium.devtools.v150.network.model.AdAncestry> adScriptAncestry;

    public AdProvenance(java.util.Optional<java.lang.String> filterlistRule, java.util.Optional<org.openqa.selenium.devtools.v150.network.model.AdAncestry> adScriptAncestry) {
        this.filterlistRule = filterlistRule;
        this.adScriptAncestry = adScriptAncestry;
    }

    /**
     * The filterlist rule that matched, if any.
     */
    public java.util.Optional<java.lang.String> getFilterlistRule() {
        return filterlistRule;
    }

    /**
     * The script ancestry that created the ad, if any.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v150.network.model.AdAncestry> getAdScriptAncestry() {
        return adScriptAncestry;
    }

    private static AdProvenance fromJson(JsonInput input) {
        java.util.Optional<java.lang.String> filterlistRule = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v150.network.model.AdAncestry> adScriptAncestry = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "filterlistRule":
                    filterlistRule = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "adScriptAncestry":
                    adScriptAncestry = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v150.network.model.AdAncestry.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AdProvenance(filterlistRule, adScriptAncestry);
    }
}
