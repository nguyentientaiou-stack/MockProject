package org.openqa.selenium.devtools.v150.ads.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Ad metrics for a page.
 */
public class AdMetrics {

    private final java.lang.Integer viewportAdDensityByArea;

    private final java.lang.Number averageViewportAdDensityByArea;

    private final java.lang.Integer viewportAdCount;

    private final java.lang.Number averageViewportAdCount;

    private final java.lang.Number totalAdCpuTime;

    private final java.lang.Number totalAdNetworkBytes;

    public AdMetrics(java.lang.Integer viewportAdDensityByArea, java.lang.Number averageViewportAdDensityByArea, java.lang.Integer viewportAdCount, java.lang.Number averageViewportAdCount, java.lang.Number totalAdCpuTime, java.lang.Number totalAdNetworkBytes) {
        this.viewportAdDensityByArea = java.util.Objects.requireNonNull(viewportAdDensityByArea, "viewportAdDensityByArea is required");
        this.averageViewportAdDensityByArea = java.util.Objects.requireNonNull(averageViewportAdDensityByArea, "averageViewportAdDensityByArea is required");
        this.viewportAdCount = java.util.Objects.requireNonNull(viewportAdCount, "viewportAdCount is required");
        this.averageViewportAdCount = java.util.Objects.requireNonNull(averageViewportAdCount, "averageViewportAdCount is required");
        this.totalAdCpuTime = java.util.Objects.requireNonNull(totalAdCpuTime, "totalAdCpuTime is required");
        this.totalAdNetworkBytes = java.util.Objects.requireNonNull(totalAdNetworkBytes, "totalAdNetworkBytes is required");
    }

    /**
     * The viewport ad density by area, represented as a percentage (an integer
     * between 0 and 100).
     */
    public java.lang.Integer getViewportAdDensityByArea() {
        return viewportAdDensityByArea;
    }

    /**
     * The time-weighted average of the viewport ad density by area, measured
     * across the duration of the page.
     */
    public java.lang.Number getAverageViewportAdDensityByArea() {
        return averageViewportAdDensityByArea;
    }

    /**
     * The number of ads currently visible within the viewport.
     */
    public java.lang.Integer getViewportAdCount() {
        return viewportAdCount;
    }

    /**
     * The time-weighted average of the viewport ad count, measured across the
     * duration of the page.
     */
    public java.lang.Number getAverageViewportAdCount() {
        return averageViewportAdCount;
    }

    /**
     * The total ad CPU usage, in milliseconds.
     */
    public java.lang.Number getTotalAdCpuTime() {
        return totalAdCpuTime;
    }

    /**
     * The total ad network bytes.
     */
    public java.lang.Number getTotalAdNetworkBytes() {
        return totalAdNetworkBytes;
    }

    private static AdMetrics fromJson(JsonInput input) {
        java.lang.Integer viewportAdDensityByArea = 0;
        java.lang.Number averageViewportAdDensityByArea = 0;
        java.lang.Integer viewportAdCount = 0;
        java.lang.Number averageViewportAdCount = 0;
        java.lang.Number totalAdCpuTime = 0;
        java.lang.Number totalAdNetworkBytes = 0;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "viewportAdDensityByArea":
                    viewportAdDensityByArea = input.nextNumber().intValue();
                    break;
                case "averageViewportAdDensityByArea":
                    averageViewportAdDensityByArea = input.nextNumber();
                    break;
                case "viewportAdCount":
                    viewportAdCount = input.nextNumber().intValue();
                    break;
                case "averageViewportAdCount":
                    averageViewportAdCount = input.nextNumber();
                    break;
                case "totalAdCpuTime":
                    totalAdCpuTime = input.nextNumber();
                    break;
                case "totalAdNetworkBytes":
                    totalAdNetworkBytes = input.nextNumber();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AdMetrics(viewportAdDensityByArea, averageViewportAdDensityByArea, viewportAdCount, averageViewportAdCount, totalAdCpuTime, totalAdNetworkBytes);
    }
}
