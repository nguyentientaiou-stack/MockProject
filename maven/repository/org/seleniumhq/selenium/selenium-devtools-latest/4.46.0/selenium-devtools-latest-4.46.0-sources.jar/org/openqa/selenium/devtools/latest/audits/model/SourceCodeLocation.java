package org.openqa.selenium.devtools.latest.audits.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class SourceCodeLocation {

    private final java.util.Optional<org.openqa.selenium.devtools.latest.runtime.model.ScriptId> scriptId;

    private final java.lang.String url;

    private final java.lang.Integer lineNumber;

    private final java.lang.Integer columnNumber;

    public SourceCodeLocation(java.util.Optional<org.openqa.selenium.devtools.latest.runtime.model.ScriptId> scriptId, java.lang.String url, java.lang.Integer lineNumber, java.lang.Integer columnNumber) {
        this.scriptId = scriptId;
        this.url = java.util.Objects.requireNonNull(url, "url is required");
        this.lineNumber = java.util.Objects.requireNonNull(lineNumber, "lineNumber is required");
        this.columnNumber = java.util.Objects.requireNonNull(columnNumber, "columnNumber is required");
    }

    public java.util.Optional<org.openqa.selenium.devtools.latest.runtime.model.ScriptId> getScriptId() {
        return scriptId;
    }

    public java.lang.String getUrl() {
        return url;
    }

    public java.lang.Integer getLineNumber() {
        return lineNumber;
    }

    public java.lang.Integer getColumnNumber() {
        return columnNumber;
    }

    private static SourceCodeLocation fromJson(JsonInput input) {
        java.util.Optional<org.openqa.selenium.devtools.latest.runtime.model.ScriptId> scriptId = java.util.Optional.empty();
        java.lang.String url = null;
        java.lang.Integer lineNumber = 0;
        java.lang.Integer columnNumber = 0;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "scriptId":
                    scriptId = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.latest.runtime.model.ScriptId.class));
                    break;
                case "url":
                    url = input.nextString();
                    break;
                case "lineNumber":
                    lineNumber = input.nextNumber().intValue();
                    break;
                case "columnNumber":
                    columnNumber = input.nextNumber().intValue();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new SourceCodeLocation(scriptId, url, lineNumber, columnNumber);
    }
}
