package org.openqa.selenium.devtools.latest.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Triggered when a device bound session event occurs.
 */
@org.openqa.selenium.Beta()
public class DeviceBoundSessionEventOccurred {

    private final org.openqa.selenium.devtools.latest.network.model.DeviceBoundSessionEventId eventId;

    private final java.lang.String site;

    private final java.lang.Boolean succeeded;

    private final java.util.Optional<java.lang.String> sessionId;

    private final java.util.Optional<org.openqa.selenium.devtools.latest.network.model.CreationEventDetails> creationEventDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.latest.network.model.RefreshEventDetails> refreshEventDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.latest.network.model.TerminationEventDetails> terminationEventDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.latest.network.model.ChallengeEventDetails> challengeEventDetails;

    public DeviceBoundSessionEventOccurred(org.openqa.selenium.devtools.latest.network.model.DeviceBoundSessionEventId eventId, java.lang.String site, java.lang.Boolean succeeded, java.util.Optional<java.lang.String> sessionId, java.util.Optional<org.openqa.selenium.devtools.latest.network.model.CreationEventDetails> creationEventDetails, java.util.Optional<org.openqa.selenium.devtools.latest.network.model.RefreshEventDetails> refreshEventDetails, java.util.Optional<org.openqa.selenium.devtools.latest.network.model.TerminationEventDetails> terminationEventDetails, java.util.Optional<org.openqa.selenium.devtools.latest.network.model.ChallengeEventDetails> challengeEventDetails) {
        this.eventId = java.util.Objects.requireNonNull(eventId, "eventId is required");
        this.site = java.util.Objects.requireNonNull(site, "site is required");
        this.succeeded = java.util.Objects.requireNonNull(succeeded, "succeeded is required");
        this.sessionId = sessionId;
        this.creationEventDetails = creationEventDetails;
        this.refreshEventDetails = refreshEventDetails;
        this.terminationEventDetails = terminationEventDetails;
        this.challengeEventDetails = challengeEventDetails;
    }

    /**
     * A unique identifier for this session event.
     */
    public org.openqa.selenium.devtools.latest.network.model.DeviceBoundSessionEventId getEventId() {
        return eventId;
    }

    /**
     * The site this session event is associated with.
     */
    public java.lang.String getSite() {
        return site;
    }

    /**
     * Whether this event was considered successful.
     */
    public java.lang.Boolean getSucceeded() {
        return succeeded;
    }

    /**
     * The session ID this event is associated with. May not be populated for
     * failed events.
     */
    public java.util.Optional<java.lang.String> getSessionId() {
        return sessionId;
    }

    /**
     * The below are the different session event type details. Exactly one is populated.
     */
    public java.util.Optional<org.openqa.selenium.devtools.latest.network.model.CreationEventDetails> getCreationEventDetails() {
        return creationEventDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.latest.network.model.RefreshEventDetails> getRefreshEventDetails() {
        return refreshEventDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.latest.network.model.TerminationEventDetails> getTerminationEventDetails() {
        return terminationEventDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.latest.network.model.ChallengeEventDetails> getChallengeEventDetails() {
        return challengeEventDetails;
    }

    private static DeviceBoundSessionEventOccurred fromJson(JsonInput input) {
        org.openqa.selenium.devtools.latest.network.model.DeviceBoundSessionEventId eventId = null;
        java.lang.String site = null;
        java.lang.Boolean succeeded = false;
        java.util.Optional<java.lang.String> sessionId = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.latest.network.model.CreationEventDetails> creationEventDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.latest.network.model.RefreshEventDetails> refreshEventDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.latest.network.model.TerminationEventDetails> terminationEventDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.latest.network.model.ChallengeEventDetails> challengeEventDetails = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "eventId":
                    eventId = input.read(org.openqa.selenium.devtools.latest.network.model.DeviceBoundSessionEventId.class);
                    break;
                case "site":
                    site = input.nextString();
                    break;
                case "succeeded":
                    succeeded = input.nextBoolean();
                    break;
                case "sessionId":
                    sessionId = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "creationEventDetails":
                    creationEventDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.latest.network.model.CreationEventDetails.class));
                    break;
                case "refreshEventDetails":
                    refreshEventDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.latest.network.model.RefreshEventDetails.class));
                    break;
                case "terminationEventDetails":
                    terminationEventDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.latest.network.model.TerminationEventDetails.class));
                    break;
                case "challengeEventDetails":
                    challengeEventDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.latest.network.model.ChallengeEventDetails.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new DeviceBoundSessionEventOccurred(eventId, site, succeeded, sessionId, creationEventDetails, refreshEventDetails, terminationEventDetails, challengeEventDetails);
    }
}
