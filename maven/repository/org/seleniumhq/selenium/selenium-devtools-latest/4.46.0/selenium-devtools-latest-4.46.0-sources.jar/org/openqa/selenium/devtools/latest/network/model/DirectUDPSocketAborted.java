package org.openqa.selenium.devtools.latest.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when direct_socket.UDPSocket is aborted.
 */
@org.openqa.selenium.Beta()
public class DirectUDPSocketAborted {

    private final org.openqa.selenium.devtools.latest.network.model.RequestId identifier;

    private final java.lang.String errorMessage;

    private final org.openqa.selenium.devtools.latest.network.model.MonotonicTime timestamp;

    public DirectUDPSocketAborted(org.openqa.selenium.devtools.latest.network.model.RequestId identifier, java.lang.String errorMessage, org.openqa.selenium.devtools.latest.network.model.MonotonicTime timestamp) {
        this.identifier = java.util.Objects.requireNonNull(identifier, "identifier is required");
        this.errorMessage = java.util.Objects.requireNonNull(errorMessage, "errorMessage is required");
        this.timestamp = java.util.Objects.requireNonNull(timestamp, "timestamp is required");
    }

    public org.openqa.selenium.devtools.latest.network.model.RequestId getIdentifier() {
        return identifier;
    }

    public java.lang.String getErrorMessage() {
        return errorMessage;
    }

    public org.openqa.selenium.devtools.latest.network.model.MonotonicTime getTimestamp() {
        return timestamp;
    }

    private static DirectUDPSocketAborted fromJson(JsonInput input) {
        org.openqa.selenium.devtools.latest.network.model.RequestId identifier = null;
        java.lang.String errorMessage = null;
        org.openqa.selenium.devtools.latest.network.model.MonotonicTime timestamp = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "identifier":
                    identifier = input.read(org.openqa.selenium.devtools.latest.network.model.RequestId.class);
                    break;
                case "errorMessage":
                    errorMessage = input.nextString();
                    break;
                case "timestamp":
                    timestamp = input.read(org.openqa.selenium.devtools.latest.network.model.MonotonicTime.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new DirectUDPSocketAborted(identifier, errorMessage, timestamp);
    }
}
