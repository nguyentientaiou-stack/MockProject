package org.openqa.selenium.devtools.latest.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * A fetch result for a device bound session creation or refresh.
 */
@org.openqa.selenium.Beta()
public enum DeviceBoundSessionFetchResult {

    SUCCESS("Success"),
    KEYERROR("KeyError"),
    SIGNINGERROR("SigningError"),
    TRANSIENTSIGNINGERROR("TransientSigningError"),
    SERVERREQUESTEDTERMINATION("ServerRequestedTermination"),
    INVALIDSESSIONID("InvalidSessionId"),
    INVALIDCHALLENGE("InvalidChallenge"),
    TOOMANYCHALLENGES("TooManyChallenges"),
    INVALIDFETCHERURL("InvalidFetcherUrl"),
    INVALIDREFRESHURL("InvalidRefreshUrl"),
    TRANSIENTHTTPERROR("TransientHttpError"),
    SCOPEORIGINSAMESITEMISMATCH("ScopeOriginSameSiteMismatch"),
    REFRESHURLSAMESITEMISMATCH("RefreshUrlSameSiteMismatch"),
    MISMATCHEDSESSIONID("MismatchedSessionId"),
    MISSINGSCOPE("MissingScope"),
    NOCREDENTIALS("NoCredentials"),
    SUBDOMAINREGISTRATIONWELLKNOWNUNAVAILABLE("SubdomainRegistrationWellKnownUnavailable"),
    SUBDOMAINREGISTRATIONUNAUTHORIZED("SubdomainRegistrationUnauthorized"),
    SUBDOMAINREGISTRATIONWELLKNOWNMALFORMED("SubdomainRegistrationWellKnownMalformed"),
    SESSIONPROVIDERWELLKNOWNUNAVAILABLE("SessionProviderWellKnownUnavailable"),
    RELYINGPARTYWELLKNOWNUNAVAILABLE("RelyingPartyWellKnownUnavailable"),
    FEDERATEDKEYTHUMBPRINTMISMATCH("FederatedKeyThumbprintMismatch"),
    INVALIDFEDERATEDSESSIONURL("InvalidFederatedSessionUrl"),
    INVALIDFEDERATEDKEY("InvalidFederatedKey"),
    TOOMANYRELYINGORIGINLABELS("TooManyRelyingOriginLabels"),
    BOUNDCOOKIESETFORBIDDEN("BoundCookieSetForbidden"),
    NETERROR("NetError"),
    PROXYERROR("ProxyError"),
    EMPTYSESSIONCONFIG("EmptySessionConfig"),
    INVALIDCREDENTIALSCONFIG("InvalidCredentialsConfig"),
    INVALIDCREDENTIALSTYPE("InvalidCredentialsType"),
    INVALIDCREDENTIALSEMPTYNAME("InvalidCredentialsEmptyName"),
    INVALIDCREDENTIALSCOOKIE("InvalidCredentialsCookie"),
    PERSISTENTHTTPERROR("PersistentHttpError"),
    REGISTRATIONATTEMPTEDCHALLENGE("RegistrationAttemptedChallenge"),
    INVALIDSCOPEORIGIN("InvalidScopeOrigin"),
    SCOPEORIGINCONTAINSPATH("ScopeOriginContainsPath"),
    REFRESHINITIATORNOTSTRING("RefreshInitiatorNotString"),
    REFRESHINITIATORINVALIDHOSTPATTERN("RefreshInitiatorInvalidHostPattern"),
    INVALIDSCOPESPECIFICATION("InvalidScopeSpecification"),
    MISSINGSCOPESPECIFICATIONTYPE("MissingScopeSpecificationType"),
    EMPTYSCOPESPECIFICATIONDOMAIN("EmptyScopeSpecificationDomain"),
    EMPTYSCOPESPECIFICATIONPATH("EmptyScopeSpecificationPath"),
    INVALIDSCOPESPECIFICATIONTYPE("InvalidScopeSpecificationType"),
    INVALIDSCOPEINCLUDESITE("InvalidScopeIncludeSite"),
    MISSINGSCOPEINCLUDESITE("MissingScopeIncludeSite"),
    FEDERATEDNOTAUTHORIZEDBYPROVIDER("FederatedNotAuthorizedByProvider"),
    FEDERATEDNOTAUTHORIZEDBYRELYINGPARTY("FederatedNotAuthorizedByRelyingParty"),
    SESSIONPROVIDERWELLKNOWNMALFORMED("SessionProviderWellKnownMalformed"),
    SESSIONPROVIDERWELLKNOWNHASPROVIDERORIGIN("SessionProviderWellKnownHasProviderOrigin"),
    RELYINGPARTYWELLKNOWNMALFORMED("RelyingPartyWellKnownMalformed"),
    RELYINGPARTYWELLKNOWNHASRELYINGORIGINS("RelyingPartyWellKnownHasRelyingOrigins"),
    INVALIDFEDERATEDSESSIONPROVIDERSESSIONMISSING("InvalidFederatedSessionProviderSessionMissing"),
    INVALIDFEDERATEDSESSIONWRONGPROVIDERORIGIN("InvalidFederatedSessionWrongProviderOrigin"),
    INVALIDCREDENTIALSCOOKIECREATIONTIME("InvalidCredentialsCookieCreationTime"),
    INVALIDCREDENTIALSCOOKIENAME("InvalidCredentialsCookieName"),
    INVALIDCREDENTIALSCOOKIEPARSING("InvalidCredentialsCookieParsing"),
    INVALIDCREDENTIALSCOOKIEUNPERMITTEDATTRIBUTE("InvalidCredentialsCookieUnpermittedAttribute"),
    INVALIDCREDENTIALSCOOKIEINVALIDDOMAIN("InvalidCredentialsCookieInvalidDomain"),
    INVALIDCREDENTIALSCOOKIEPREFIX("InvalidCredentialsCookiePrefix"),
    INVALIDSCOPERULEPATH("InvalidScopeRulePath"),
    INVALIDSCOPERULEHOSTPATTERN("InvalidScopeRuleHostPattern"),
    SCOPERULEORIGINSCOPEDHOSTPATTERNMISMATCH("ScopeRuleOriginScopedHostPatternMismatch"),
    SCOPERULESITESCOPEDHOSTPATTERNMISMATCH("ScopeRuleSiteScopedHostPatternMismatch"),
    SIGNINGQUOTAEXCEEDED("SigningQuotaExceeded"),
    INVALIDCONFIGJSON("InvalidConfigJson"),
    INVALIDFEDERATEDSESSIONPROVIDERFAILEDTORESTOREKEY("InvalidFederatedSessionProviderFailedToRestoreKey"),
    FAILEDTOUNWRAPKEY("FailedToUnwrapKey"),
    SESSIONDELETEDDURINGREFRESH("SessionDeletedDuringRefresh"),
    CROSSORIGINREGISTRATIONSITENOTINCLUDED("CrossOriginRegistrationSiteNotIncluded");

    private String value;

    DeviceBoundSessionFetchResult(String value) {
        this.value = value;
    }

    public static DeviceBoundSessionFetchResult fromString(String s) {
        return java.util.Arrays.stream(DeviceBoundSessionFetchResult.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within DeviceBoundSessionFetchResult "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static DeviceBoundSessionFetchResult fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}
