package org.openqa.selenium.devtools.latest.extensions.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Detailed information about an extension.
 */
public class ExtensionInfo {

    private final java.lang.String id;

    private final java.lang.String name;

    private final java.lang.String version;

    private final java.lang.String path;

    private final java.lang.Boolean enabled;

    public ExtensionInfo(java.lang.String id, java.lang.String name, java.lang.String version, java.lang.String path, java.lang.Boolean enabled) {
        this.id = java.util.Objects.requireNonNull(id, "id is required");
        this.name = java.util.Objects.requireNonNull(name, "name is required");
        this.version = java.util.Objects.requireNonNull(version, "version is required");
        this.path = java.util.Objects.requireNonNull(path, "path is required");
        this.enabled = java.util.Objects.requireNonNull(enabled, "enabled is required");
    }

    /**
     * Extension id.
     */
    public java.lang.String getId() {
        return id;
    }

    /**
     * Extension name.
     */
    public java.lang.String getName() {
        return name;
    }

    /**
     * Extension version.
     */
    public java.lang.String getVersion() {
        return version;
    }

    /**
     * The path from which the extension was loaded.
     */
    public java.lang.String getPath() {
        return path;
    }

    /**
     * Extension enabled status.
     */
    public java.lang.Boolean getEnabled() {
        return enabled;
    }

    private static ExtensionInfo fromJson(JsonInput input) {
        java.lang.String id = null;
        java.lang.String name = null;
        java.lang.String version = null;
        java.lang.String path = null;
        java.lang.Boolean enabled = false;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "id":
                    id = input.nextString();
                    break;
                case "name":
                    name = input.nextString();
                    break;
                case "version":
                    version = input.nextString();
                    break;
                case "path":
                    path = input.nextString();
                    break;
                case "enabled":
                    enabled = input.nextBoolean();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ExtensionInfo(id, name, version, path, enabled);
    }
}
