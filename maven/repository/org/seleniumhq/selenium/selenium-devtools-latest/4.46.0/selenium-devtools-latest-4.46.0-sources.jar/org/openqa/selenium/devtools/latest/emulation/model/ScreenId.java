package org.openqa.selenium.devtools.latest.emulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class ScreenId {

    private final java.lang.String screenId;

    public ScreenId(java.lang.String screenId) {
        this.screenId = java.util.Objects.requireNonNull(screenId, "Missing value for ScreenId");
    }

    private static ScreenId fromJson(JsonInput input) {
        return new ScreenId(input.nextString());
    }

    public String toJson() {
        return screenId.toString();
    }

    public String toString() {
        return screenId.toString();
    }
}
