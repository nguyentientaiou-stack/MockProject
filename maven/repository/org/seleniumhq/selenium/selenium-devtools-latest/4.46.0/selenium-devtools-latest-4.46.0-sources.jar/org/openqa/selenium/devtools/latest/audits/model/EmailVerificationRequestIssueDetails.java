package org.openqa.selenium.devtools.latest.audits.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class EmailVerificationRequestIssueDetails {

    private final org.openqa.selenium.devtools.latest.audits.model.EmailVerificationRequestIssueReason emailVerificationRequestIssueReason;

    public EmailVerificationRequestIssueDetails(org.openqa.selenium.devtools.latest.audits.model.EmailVerificationRequestIssueReason emailVerificationRequestIssueReason) {
        this.emailVerificationRequestIssueReason = java.util.Objects.requireNonNull(emailVerificationRequestIssueReason, "emailVerificationRequestIssueReason is required");
    }

    public org.openqa.selenium.devtools.latest.audits.model.EmailVerificationRequestIssueReason getEmailVerificationRequestIssueReason() {
        return emailVerificationRequestIssueReason;
    }

    private static EmailVerificationRequestIssueDetails fromJson(JsonInput input) {
        org.openqa.selenium.devtools.latest.audits.model.EmailVerificationRequestIssueReason emailVerificationRequestIssueReason = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "emailVerificationRequestIssueReason":
                    emailVerificationRequestIssueReason = input.read(org.openqa.selenium.devtools.latest.audits.model.EmailVerificationRequestIssueReason.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new EmailVerificationRequestIssueDetails(emailVerificationRequestIssueReason);
    }
}
