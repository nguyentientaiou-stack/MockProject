package org.openqa.selenium.devtools.latest.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * The render-blocking behavior of a resource request.
 */
@org.openqa.selenium.Beta()
public enum RenderBlockingBehavior {

    BLOCKING("Blocking"), INBODYPARSERBLOCKING("InBodyParserBlocking"), NONBLOCKING("NonBlocking"), NONBLOCKINGDYNAMIC("NonBlockingDynamic"), POTENTIALLYBLOCKING("PotentiallyBlocking");

    private String value;

    RenderBlockingBehavior(String value) {
        this.value = value;
    }

    public static RenderBlockingBehavior fromString(String s) {
        return java.util.Arrays.stream(RenderBlockingBehavior.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within RenderBlockingBehavior "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static RenderBlockingBehavior fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}
