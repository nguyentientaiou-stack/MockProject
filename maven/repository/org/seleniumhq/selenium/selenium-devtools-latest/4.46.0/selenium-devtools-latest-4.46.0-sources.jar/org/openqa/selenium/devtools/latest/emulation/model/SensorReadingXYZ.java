package org.openqa.selenium.devtools.latest.emulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class SensorReadingXYZ {

    private final java.lang.Number x;

    private final java.lang.Number y;

    private final java.lang.Number z;

    public SensorReadingXYZ(java.lang.Number x, java.lang.Number y, java.lang.Number z) {
        this.x = java.util.Objects.requireNonNull(x, "x is required");
        this.y = java.util.Objects.requireNonNull(y, "y is required");
        this.z = java.util.Objects.requireNonNull(z, "z is required");
    }

    public java.lang.Number getX() {
        return x;
    }

    public java.lang.Number getY() {
        return y;
    }

    public java.lang.Number getZ() {
        return z;
    }

    private static SensorReadingXYZ fromJson(JsonInput input) {
        java.lang.Number x = 0;
        java.lang.Number y = 0;
        java.lang.Number z = 0;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "x":
                    x = input.nextNumber();
                    break;
                case "y":
                    y = input.nextNumber();
                    break;
                case "z":
                    z = input.nextNumber();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new SensorReadingXYZ(x, y, z);
    }
}
