package org.openqa.selenium.devtools.latest.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * A device bound session's cookie craving.
 */
@org.openqa.selenium.Beta()
public class DeviceBoundSessionCookieCraving {

    private final java.lang.String name;

    private final java.lang.String domain;

    private final java.lang.String path;

    private final java.lang.Boolean secure;

    private final java.lang.Boolean httpOnly;

    private final java.util.Optional<org.openqa.selenium.devtools.latest.network.model.CookieSameSite> sameSite;

    public DeviceBoundSessionCookieCraving(java.lang.String name, java.lang.String domain, java.lang.String path, java.lang.Boolean secure, java.lang.Boolean httpOnly, java.util.Optional<org.openqa.selenium.devtools.latest.network.model.CookieSameSite> sameSite) {
        this.name = java.util.Objects.requireNonNull(name, "name is required");
        this.domain = java.util.Objects.requireNonNull(domain, "domain is required");
        this.path = java.util.Objects.requireNonNull(path, "path is required");
        this.secure = java.util.Objects.requireNonNull(secure, "secure is required");
        this.httpOnly = java.util.Objects.requireNonNull(httpOnly, "httpOnly is required");
        this.sameSite = sameSite;
    }

    /**
     * The name of the craving.
     */
    public java.lang.String getName() {
        return name;
    }

    /**
     * The domain of the craving.
     */
    public java.lang.String getDomain() {
        return domain;
    }

    /**
     * The path of the craving.
     */
    public java.lang.String getPath() {
        return path;
    }

    /**
     * The `Secure` attribute of the craving attributes.
     */
    public java.lang.Boolean getSecure() {
        return secure;
    }

    /**
     * The `HttpOnly` attribute of the craving attributes.
     */
    public java.lang.Boolean getHttpOnly() {
        return httpOnly;
    }

    /**
     * The `SameSite` attribute of the craving attributes.
     */
    public java.util.Optional<org.openqa.selenium.devtools.latest.network.model.CookieSameSite> getSameSite() {
        return sameSite;
    }

    private static DeviceBoundSessionCookieCraving fromJson(JsonInput input) {
        java.lang.String name = null;
        java.lang.String domain = null;
        java.lang.String path = null;
        java.lang.Boolean secure = false;
        java.lang.Boolean httpOnly = false;
        java.util.Optional<org.openqa.selenium.devtools.latest.network.model.CookieSameSite> sameSite = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "name":
                    name = input.nextString();
                    break;
                case "domain":
                    domain = input.nextString();
                    break;
                case "path":
                    path = input.nextString();
                    break;
                case "secure":
                    secure = input.nextBoolean();
                    break;
                case "httpOnly":
                    httpOnly = input.nextBoolean();
                    break;
                case "sameSite":
                    sameSite = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.latest.network.model.CookieSameSite.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new DeviceBoundSessionCookieCraving(name, domain, path, secure, httpOnly, sameSite);
    }
}
