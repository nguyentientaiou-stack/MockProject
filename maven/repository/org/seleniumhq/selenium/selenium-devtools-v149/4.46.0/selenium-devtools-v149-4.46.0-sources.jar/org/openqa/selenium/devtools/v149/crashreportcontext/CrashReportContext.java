package org.openqa.selenium.devtools.v149.crashreportcontext;

import org.openqa.selenium.Beta;
import org.openqa.selenium.devtools.Command;
import org.openqa.selenium.devtools.Event;
import org.openqa.selenium.devtools.ConverterFunctions;
import java.util.Map;
import java.util.LinkedHashMap;
import org.openqa.selenium.json.JsonInput;

/**
 * This domain exposes the current state of the CrashReportContext API.
 */
@Beta()
public class CrashReportContext {

    /**
     * Returns all entries in the CrashReportContext across all frames in the page.
     */
    public static Command<java.util.List<org.openqa.selenium.devtools.v149.crashreportcontext.model.CrashReportContextEntry>> getEntries() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("CrashReportContext.getEntries", Map.copyOf(params), ConverterFunctions.map("entries", input -> input.readArray(org.openqa.selenium.devtools.v149.crashreportcontext.model.CrashReportContextEntry.class)));
    }
}
