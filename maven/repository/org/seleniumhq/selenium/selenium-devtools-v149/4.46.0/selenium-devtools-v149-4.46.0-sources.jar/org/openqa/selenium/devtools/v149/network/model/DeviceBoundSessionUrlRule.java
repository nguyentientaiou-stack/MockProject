package org.openqa.selenium.devtools.v149.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * A device bound session's inclusion URL rule.
 */
@org.openqa.selenium.Beta()
public class DeviceBoundSessionUrlRule {

    public enum RuleType {

        EXCLUDE("Exclude"), INCLUDE("Include");

        private String value;

        RuleType(String value) {
            this.value = value;
        }

        public static RuleType fromString(String s) {
            return java.util.Arrays.stream(RuleType.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within RuleType "));
        }

        public String toString() {
            return value;
        }

        public String toJson() {
            return value;
        }

        private static RuleType fromJson(JsonInput input) {
            return fromString(input.nextString());
        }
    }

    private final RuleType ruleType;

    private final java.lang.String hostPattern;

    private final java.lang.String pathPrefix;

    public DeviceBoundSessionUrlRule(RuleType ruleType, java.lang.String hostPattern, java.lang.String pathPrefix) {
        this.ruleType = java.util.Objects.requireNonNull(ruleType, "ruleType is required");
        this.hostPattern = java.util.Objects.requireNonNull(hostPattern, "hostPattern is required");
        this.pathPrefix = java.util.Objects.requireNonNull(pathPrefix, "pathPrefix is required");
    }

    /**
     * See comments on `net::device_bound_sessions::SessionInclusionRules::UrlRule::rule_type`.
     */
    public RuleType getRuleType() {
        return ruleType;
    }

    /**
     * See comments on `net::device_bound_sessions::SessionInclusionRules::UrlRule::host_pattern`.
     */
    public java.lang.String getHostPattern() {
        return hostPattern;
    }

    /**
     * See comments on `net::device_bound_sessions::SessionInclusionRules::UrlRule::path_prefix`.
     */
    public java.lang.String getPathPrefix() {
        return pathPrefix;
    }

    private static DeviceBoundSessionUrlRule fromJson(JsonInput input) {
        RuleType ruleType = null;
        java.lang.String hostPattern = null;
        java.lang.String pathPrefix = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "ruleType":
                    ruleType = RuleType.fromString(input.nextString());
                    break;
                case "hostPattern":
                    hostPattern = input.nextString();
                    break;
                case "pathPrefix":
                    pathPrefix = input.nextString();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new DeviceBoundSessionUrlRule(ruleType, hostPattern, pathPrefix);
    }
}
