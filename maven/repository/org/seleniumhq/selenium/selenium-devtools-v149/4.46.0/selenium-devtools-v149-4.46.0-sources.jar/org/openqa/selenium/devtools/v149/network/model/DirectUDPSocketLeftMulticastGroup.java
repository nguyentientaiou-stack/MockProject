package org.openqa.selenium.devtools.v149.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class DirectUDPSocketLeftMulticastGroup {

    private final org.openqa.selenium.devtools.v149.network.model.RequestId identifier;

    private final java.lang.String IPAddress;

    public DirectUDPSocketLeftMulticastGroup(org.openqa.selenium.devtools.v149.network.model.RequestId identifier, java.lang.String IPAddress) {
        this.identifier = java.util.Objects.requireNonNull(identifier, "identifier is required");
        this.IPAddress = java.util.Objects.requireNonNull(IPAddress, "IPAddress is required");
    }

    public org.openqa.selenium.devtools.v149.network.model.RequestId getIdentifier() {
        return identifier;
    }

    public java.lang.String getIPAddress() {
        return IPAddress;
    }

    private static DirectUDPSocketLeftMulticastGroup fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v149.network.model.RequestId identifier = null;
        java.lang.String IPAddress = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "identifier":
                    identifier = input.read(org.openqa.selenium.devtools.v149.network.model.RequestId.class);
                    break;
                case "IPAddress":
                    IPAddress = input.nextString();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new DirectUDPSocketLeftMulticastGroup(identifier, IPAddress);
    }
}
