package org.openqa.selenium.devtools.v149.domsnapshot.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Index of the string in the strings table.
 */
public class ArrayOfStrings {

    private final java.util.List<org.openqa.selenium.devtools.v149.domsnapshot.model.StringIndex> arrayOfStrings;

    public ArrayOfStrings(java.util.List<org.openqa.selenium.devtools.v149.domsnapshot.model.StringIndex> arrayOfStrings) {
        this.arrayOfStrings = java.util.Objects.requireNonNull(arrayOfStrings, "Missing value for ArrayOfStrings");
    }

    private static ArrayOfStrings fromJson(JsonInput input) {
        return new ArrayOfStrings(input.readArray(org.openqa.selenium.devtools.v149.domsnapshot.model.StringIndex.class));
    }

    public java.util.List<org.openqa.selenium.devtools.v149.domsnapshot.model.StringIndex> getArrayOfStrings() {
        return arrayOfStrings;
    }

    public String toString() {
        return arrayOfStrings.toString();
    }
}
