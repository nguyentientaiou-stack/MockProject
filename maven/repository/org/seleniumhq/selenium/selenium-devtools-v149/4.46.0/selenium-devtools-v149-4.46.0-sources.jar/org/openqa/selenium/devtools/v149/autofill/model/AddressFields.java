package org.openqa.selenium.devtools.v149.autofill.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * A list of address fields.
 */
public class AddressFields {

    private final java.util.List<org.openqa.selenium.devtools.v149.autofill.model.AddressField> fields;

    public AddressFields(java.util.List<org.openqa.selenium.devtools.v149.autofill.model.AddressField> fields) {
        this.fields = java.util.Objects.requireNonNull(fields, "fields is required");
    }

    public java.util.List<org.openqa.selenium.devtools.v149.autofill.model.AddressField> getFields() {
        return fields;
    }

    private static AddressFields fromJson(JsonInput input) {
        java.util.List<org.openqa.selenium.devtools.v149.autofill.model.AddressField> fields = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "fields":
                    fields = input.readArray(org.openqa.selenium.devtools.v149.autofill.model.AddressField.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AddressFields(fields);
    }
}
