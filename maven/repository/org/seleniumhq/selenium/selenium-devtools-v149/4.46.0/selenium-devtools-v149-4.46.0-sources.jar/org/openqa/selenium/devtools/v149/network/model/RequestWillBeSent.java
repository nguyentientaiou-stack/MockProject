package org.openqa.selenium.devtools.v149.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when page is about to send HTTP request.
 */
public class RequestWillBeSent {

    private final org.openqa.selenium.devtools.v149.network.model.RequestId requestId;

    private final org.openqa.selenium.devtools.v149.network.model.LoaderId loaderId;

    private final java.lang.String documentURL;

    private final org.openqa.selenium.devtools.v149.network.model.Request request;

    private final org.openqa.selenium.devtools.v149.network.model.MonotonicTime timestamp;

    private final org.openqa.selenium.devtools.v149.network.model.TimeSinceEpoch wallTime;

    private final org.openqa.selenium.devtools.v149.network.model.Initiator initiator;

    private final java.lang.Boolean redirectHasExtraInfo;

    private final java.util.Optional<org.openqa.selenium.devtools.v149.network.model.Response> redirectResponse;

    private final java.util.Optional<org.openqa.selenium.devtools.v149.network.model.ResourceType> type;

    private final java.util.Optional<org.openqa.selenium.devtools.v149.page.model.FrameId> frameId;

    private final java.util.Optional<java.lang.Boolean> hasUserGesture;

    private final java.util.Optional<org.openqa.selenium.devtools.v149.network.model.RenderBlockingBehavior> renderBlockingBehavior;

    public RequestWillBeSent(org.openqa.selenium.devtools.v149.network.model.RequestId requestId, org.openqa.selenium.devtools.v149.network.model.LoaderId loaderId, java.lang.String documentURL, org.openqa.selenium.devtools.v149.network.model.Request request, org.openqa.selenium.devtools.v149.network.model.MonotonicTime timestamp, org.openqa.selenium.devtools.v149.network.model.TimeSinceEpoch wallTime, org.openqa.selenium.devtools.v149.network.model.Initiator initiator, java.lang.Boolean redirectHasExtraInfo, java.util.Optional<org.openqa.selenium.devtools.v149.network.model.Response> redirectResponse, java.util.Optional<org.openqa.selenium.devtools.v149.network.model.ResourceType> type, java.util.Optional<org.openqa.selenium.devtools.v149.page.model.FrameId> frameId, java.util.Optional<java.lang.Boolean> hasUserGesture, java.util.Optional<org.openqa.selenium.devtools.v149.network.model.RenderBlockingBehavior> renderBlockingBehavior) {
        this.requestId = java.util.Objects.requireNonNull(requestId, "requestId is required");
        this.loaderId = java.util.Objects.requireNonNull(loaderId, "loaderId is required");
        this.documentURL = java.util.Objects.requireNonNull(documentURL, "documentURL is required");
        this.request = java.util.Objects.requireNonNull(request, "request is required");
        this.timestamp = java.util.Objects.requireNonNull(timestamp, "timestamp is required");
        this.wallTime = java.util.Objects.requireNonNull(wallTime, "wallTime is required");
        this.initiator = java.util.Objects.requireNonNull(initiator, "initiator is required");
        this.redirectHasExtraInfo = java.util.Objects.requireNonNull(redirectHasExtraInfo, "redirectHasExtraInfo is required");
        this.redirectResponse = redirectResponse;
        this.type = type;
        this.frameId = frameId;
        this.hasUserGesture = hasUserGesture;
        this.renderBlockingBehavior = renderBlockingBehavior;
    }

    /**
     * Request identifier.
     */
    public org.openqa.selenium.devtools.v149.network.model.RequestId getRequestId() {
        return requestId;
    }

    /**
     * Loader identifier. Empty string if the request is fetched from worker.
     */
    public org.openqa.selenium.devtools.v149.network.model.LoaderId getLoaderId() {
        return loaderId;
    }

    /**
     * URL of the document this request is loaded for.
     */
    public java.lang.String getDocumentURL() {
        return documentURL;
    }

    /**
     * Request data.
     */
    public org.openqa.selenium.devtools.v149.network.model.Request getRequest() {
        return request;
    }

    /**
     * Timestamp.
     */
    public org.openqa.selenium.devtools.v149.network.model.MonotonicTime getTimestamp() {
        return timestamp;
    }

    /**
     * Timestamp.
     */
    public org.openqa.selenium.devtools.v149.network.model.TimeSinceEpoch getWallTime() {
        return wallTime;
    }

    /**
     * Request initiator.
     */
    public org.openqa.selenium.devtools.v149.network.model.Initiator getInitiator() {
        return initiator;
    }

    /**
     * In the case that redirectResponse is populated, this flag indicates whether
     * requestWillBeSentExtraInfo and responseReceivedExtraInfo events will be or were emitted
     * for the request which was just redirected.
     */
    @Beta()
    public java.lang.Boolean getRedirectHasExtraInfo() {
        return redirectHasExtraInfo;
    }

    /**
     * Redirect response data.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v149.network.model.Response> getRedirectResponse() {
        return redirectResponse;
    }

    /**
     * Type of this resource.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v149.network.model.ResourceType> getType() {
        return type;
    }

    /**
     * Frame identifier.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v149.page.model.FrameId> getFrameId() {
        return frameId;
    }

    /**
     * Whether the request is initiated by a user gesture. Defaults to false.
     */
    public java.util.Optional<java.lang.Boolean> getHasUserGesture() {
        return hasUserGesture;
    }

    /**
     * The render-blocking behavior of the request.
     */
    @Beta()
    public java.util.Optional<org.openqa.selenium.devtools.v149.network.model.RenderBlockingBehavior> getRenderBlockingBehavior() {
        return renderBlockingBehavior;
    }

    private static RequestWillBeSent fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v149.network.model.RequestId requestId = null;
        org.openqa.selenium.devtools.v149.network.model.LoaderId loaderId = null;
        java.lang.String documentURL = null;
        org.openqa.selenium.devtools.v149.network.model.Request request = null;
        org.openqa.selenium.devtools.v149.network.model.MonotonicTime timestamp = null;
        org.openqa.selenium.devtools.v149.network.model.TimeSinceEpoch wallTime = null;
        org.openqa.selenium.devtools.v149.network.model.Initiator initiator = null;
        java.lang.Boolean redirectHasExtraInfo = false;
        java.util.Optional<org.openqa.selenium.devtools.v149.network.model.Response> redirectResponse = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v149.network.model.ResourceType> type = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v149.page.model.FrameId> frameId = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> hasUserGesture = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v149.network.model.RenderBlockingBehavior> renderBlockingBehavior = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "requestId":
                    requestId = input.read(org.openqa.selenium.devtools.v149.network.model.RequestId.class);
                    break;
                case "loaderId":
                    loaderId = input.read(org.openqa.selenium.devtools.v149.network.model.LoaderId.class);
                    break;
                case "documentURL":
                    documentURL = input.nextString();
                    break;
                case "request":
                    request = input.read(org.openqa.selenium.devtools.v149.network.model.Request.class);
                    break;
                case "timestamp":
                    timestamp = input.read(org.openqa.selenium.devtools.v149.network.model.MonotonicTime.class);
                    break;
                case "wallTime":
                    wallTime = input.read(org.openqa.selenium.devtools.v149.network.model.TimeSinceEpoch.class);
                    break;
                case "initiator":
                    initiator = input.read(org.openqa.selenium.devtools.v149.network.model.Initiator.class);
                    break;
                case "redirectHasExtraInfo":
                    redirectHasExtraInfo = input.nextBoolean();
                    break;
                case "redirectResponse":
                    redirectResponse = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.network.model.Response.class));
                    break;
                case "type":
                    type = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.network.model.ResourceType.class));
                    break;
                case "frameId":
                    frameId = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.page.model.FrameId.class));
                    break;
                case "hasUserGesture":
                    hasUserGesture = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "renderBlockingBehavior":
                    renderBlockingBehavior = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.network.model.RenderBlockingBehavior.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new RequestWillBeSent(requestId, loaderId, documentURL, request, timestamp, wallTime, initiator, redirectHasExtraInfo, redirectResponse, type, frameId, hasUserGesture, renderBlockingBehavior);
    }
}
