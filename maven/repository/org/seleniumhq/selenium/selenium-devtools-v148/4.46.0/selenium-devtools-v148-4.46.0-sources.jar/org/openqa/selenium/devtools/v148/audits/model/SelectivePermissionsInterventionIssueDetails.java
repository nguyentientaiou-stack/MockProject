package org.openqa.selenium.devtools.v148.audits.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * The issue warns about blocked calls to privacy sensitive APIs via the
 * Selective Permissions Intervention.
 */
public class SelectivePermissionsInterventionIssueDetails {

    private final java.lang.String apiName;

    private final org.openqa.selenium.devtools.v148.network.model.AdAncestry adAncestry;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.runtime.model.StackTrace> stackTrace;

    public SelectivePermissionsInterventionIssueDetails(java.lang.String apiName, org.openqa.selenium.devtools.v148.network.model.AdAncestry adAncestry, java.util.Optional<org.openqa.selenium.devtools.v148.runtime.model.StackTrace> stackTrace) {
        this.apiName = java.util.Objects.requireNonNull(apiName, "apiName is required");
        this.adAncestry = java.util.Objects.requireNonNull(adAncestry, "adAncestry is required");
        this.stackTrace = stackTrace;
    }

    /**
     * Which API was intervened on.
     */
    public java.lang.String getApiName() {
        return apiName;
    }

    /**
     * Why the ad script using the API is considered an ad.
     */
    public org.openqa.selenium.devtools.v148.network.model.AdAncestry getAdAncestry() {
        return adAncestry;
    }

    /**
     * The stack trace at the time of the intervention.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v148.runtime.model.StackTrace> getStackTrace() {
        return stackTrace;
    }

    private static SelectivePermissionsInterventionIssueDetails fromJson(JsonInput input) {
        java.lang.String apiName = null;
        org.openqa.selenium.devtools.v148.network.model.AdAncestry adAncestry = null;
        java.util.Optional<org.openqa.selenium.devtools.v148.runtime.model.StackTrace> stackTrace = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "apiName":
                    apiName = input.nextString();
                    break;
                case "adAncestry":
                    adAncestry = input.read(org.openqa.selenium.devtools.v148.network.model.AdAncestry.class);
                    break;
                case "stackTrace":
                    stackTrace = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.runtime.model.StackTrace.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new SelectivePermissionsInterventionIssueDetails(apiName, adAncestry, stackTrace);
    }
}
