package org.openqa.selenium.devtools.v148.audits.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class ConnectionAllowlistIssueDetails {

    private final org.openqa.selenium.devtools.v148.audits.model.ConnectionAllowlistError error;

    private final org.openqa.selenium.devtools.v148.audits.model.AffectedRequest request;

    public ConnectionAllowlistIssueDetails(org.openqa.selenium.devtools.v148.audits.model.ConnectionAllowlistError error, org.openqa.selenium.devtools.v148.audits.model.AffectedRequest request) {
        this.error = java.util.Objects.requireNonNull(error, "error is required");
        this.request = java.util.Objects.requireNonNull(request, "request is required");
    }

    public org.openqa.selenium.devtools.v148.audits.model.ConnectionAllowlistError getError() {
        return error;
    }

    public org.openqa.selenium.devtools.v148.audits.model.AffectedRequest getRequest() {
        return request;
    }

    private static ConnectionAllowlistIssueDetails fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v148.audits.model.ConnectionAllowlistError error = null;
        org.openqa.selenium.devtools.v148.audits.model.AffectedRequest request = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "error":
                    error = input.read(org.openqa.selenium.devtools.v148.audits.model.ConnectionAllowlistError.class);
                    break;
                case "request":
                    request = input.read(org.openqa.selenium.devtools.v148.audits.model.AffectedRequest.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ConnectionAllowlistIssueDetails(error, request);
    }
}
