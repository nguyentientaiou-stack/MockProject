package org.openqa.selenium.devtools.v148.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Unique identifier for a device bound session.
 */
@org.openqa.selenium.Beta()
public class DeviceBoundSessionKey {

    private final java.lang.String site;

    private final java.lang.String id;

    public DeviceBoundSessionKey(java.lang.String site, java.lang.String id) {
        this.site = java.util.Objects.requireNonNull(site, "site is required");
        this.id = java.util.Objects.requireNonNull(id, "id is required");
    }

    /**
     * The site the session is set up for.
     */
    public java.lang.String getSite() {
        return site;
    }

    /**
     * The id of the session.
     */
    public java.lang.String getId() {
        return id;
    }

    private static DeviceBoundSessionKey fromJson(JsonInput input) {
        java.lang.String site = null;
        java.lang.String id = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "site":
                    site = input.nextString();
                    break;
                case "id":
                    id = input.nextString();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new DeviceBoundSessionKey(site, id);
    }
}
