package org.openqa.selenium.devtools.v148.audits.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Details for a performance issue.
 */
public class PerformanceIssueDetails {

    private final org.openqa.selenium.devtools.v148.audits.model.PerformanceIssueType performanceIssueType;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SourceCodeLocation> sourceCodeLocation;

    public PerformanceIssueDetails(org.openqa.selenium.devtools.v148.audits.model.PerformanceIssueType performanceIssueType, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SourceCodeLocation> sourceCodeLocation) {
        this.performanceIssueType = java.util.Objects.requireNonNull(performanceIssueType, "performanceIssueType is required");
        this.sourceCodeLocation = sourceCodeLocation;
    }

    public org.openqa.selenium.devtools.v148.audits.model.PerformanceIssueType getPerformanceIssueType() {
        return performanceIssueType;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SourceCodeLocation> getSourceCodeLocation() {
        return sourceCodeLocation;
    }

    private static PerformanceIssueDetails fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v148.audits.model.PerformanceIssueType performanceIssueType = null;
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SourceCodeLocation> sourceCodeLocation = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "performanceIssueType":
                    performanceIssueType = input.read(org.openqa.selenium.devtools.v148.audits.model.PerformanceIssueType.class);
                    break;
                case "sourceCodeLocation":
                    sourceCodeLocation = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.SourceCodeLocation.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new PerformanceIssueDetails(performanceIssueType, sourceCodeLocation);
    }
}
