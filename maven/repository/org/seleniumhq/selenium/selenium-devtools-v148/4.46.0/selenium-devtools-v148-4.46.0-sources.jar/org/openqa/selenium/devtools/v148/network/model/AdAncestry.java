package org.openqa.selenium.devtools.v148.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Encapsulates the script ancestry and the root script filter list rule that
 * caused the resource or element to be labeled as an ad.
 */
@org.openqa.selenium.Beta()
public class AdAncestry {

    private final java.util.List<org.openqa.selenium.devtools.v148.network.model.AdScriptIdentifier> ancestryChain;

    private final java.util.Optional<java.lang.String> rootScriptFilterlistRule;

    public AdAncestry(java.util.List<org.openqa.selenium.devtools.v148.network.model.AdScriptIdentifier> ancestryChain, java.util.Optional<java.lang.String> rootScriptFilterlistRule) {
        this.ancestryChain = java.util.Objects.requireNonNull(ancestryChain, "ancestryChain is required");
        this.rootScriptFilterlistRule = rootScriptFilterlistRule;
    }

    /**
     * A chain of `AdScriptIdentifier`s representing the ancestry of an ad
     * script that led to the creation of a resource or element. The chain is
     * ordered from the script itself (lowest level) up to its root ancestor
     * that was flagged by a filter list.
     */
    public java.util.List<org.openqa.selenium.devtools.v148.network.model.AdScriptIdentifier> getAncestryChain() {
        return ancestryChain;
    }

    /**
     * The filter list rule that caused the root (last) script in
     * `ancestryChain` to be tagged as an ad.
     */
    public java.util.Optional<java.lang.String> getRootScriptFilterlistRule() {
        return rootScriptFilterlistRule;
    }

    private static AdAncestry fromJson(JsonInput input) {
        java.util.List<org.openqa.selenium.devtools.v148.network.model.AdScriptIdentifier> ancestryChain = null;
        java.util.Optional<java.lang.String> rootScriptFilterlistRule = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "ancestryChain":
                    ancestryChain = input.readArray(org.openqa.selenium.devtools.v148.network.model.AdScriptIdentifier.class);
                    break;
                case "rootScriptFilterlistRule":
                    rootScriptFilterlistRule = java.util.Optional.ofNullable(input.nextString());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AdAncestry(ancestryChain, rootScriptFilterlistRule);
    }
}
