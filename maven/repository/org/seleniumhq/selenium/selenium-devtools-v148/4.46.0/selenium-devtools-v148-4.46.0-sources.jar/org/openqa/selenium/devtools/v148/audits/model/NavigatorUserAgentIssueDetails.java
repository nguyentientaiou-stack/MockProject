package org.openqa.selenium.devtools.v148.audits.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@java.lang.Deprecated()
public class NavigatorUserAgentIssueDetails {

    private final java.lang.String url;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SourceCodeLocation> location;

    public NavigatorUserAgentIssueDetails(java.lang.String url, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SourceCodeLocation> location) {
        this.url = java.util.Objects.requireNonNull(url, "url is required");
        this.location = location;
    }

    public java.lang.String getUrl() {
        return url;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SourceCodeLocation> getLocation() {
        return location;
    }

    private static NavigatorUserAgentIssueDetails fromJson(JsonInput input) {
        java.lang.String url = null;
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SourceCodeLocation> location = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "url":
                    url = input.nextString();
                    break;
                case "location":
                    location = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.SourceCodeLocation.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new NavigatorUserAgentIssueDetails(url, location);
    }
}
