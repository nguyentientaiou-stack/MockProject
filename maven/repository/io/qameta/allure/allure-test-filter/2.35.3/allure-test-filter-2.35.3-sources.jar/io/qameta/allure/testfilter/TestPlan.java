/*
 *  Copyright 2016-2026 Qameta Software Inc
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package io.qameta.allure.testfilter;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

/**
 * Represents a loaded Allure test plan.
 *
 * <p>Integrations use this interface to decide whether discovered tests should run. Implementations may model a known plan version or an unknown plan shape while still exposing plan presence to filtering code.</p>
 */
@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        property = "version",
        defaultImpl = TestPlanUnknown.class
)
@JsonSubTypes(
    {
            @JsonSubTypes.Type(TestPlanV1_0.class)
    }
)
public interface TestPlan {
}
